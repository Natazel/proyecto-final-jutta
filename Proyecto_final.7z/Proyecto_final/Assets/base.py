

from flask import Flask, render_template, request
from flaskext.mysql import MySQL #Libreria para poder conectar a la base de datos

app = Flask(__name__)
app.secret_key = "12345678"

mysql = MySQL()
app.config["MYSQL_DATABASE_HOST"] = "localhost"
app.config["MYSQL_DATABASE_USER"] = "root"
app.config["MYSQL_DATABASE_PASSWORD"] = "26062021"
app.config["MYSQL_DATABASE_DB"] = "calcula"
mysql.init_app(app)
print("Se realizo la conexion")
#Hace la coneccion de la base de datos con la aplicacion

@app.route("/")
def index():
    return render_template("index.html")
    

@app.route("/registro", methods = ['POST'])
def registro():
    
    usuario = request.form['usuario']
    contraseña = request.form['contraseña']
    
    sql = "INSERT INTO calorias (usuario, contraseña) VALUES (%s, %s)" #%s representa los datos a insertar
    
    datos = (usuario, contraseña)
    
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute(sql, datos)
    conn.commit()
    
    return render_template("calorias.html")


if __name__ == "__main__":
    app.run(debug=True) #Para que la aplicacion siga corriendo

